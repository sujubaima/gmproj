# -- coding: utf-8 --

# 婴青凤
PERSON_YING_QINGFENG = \
    {"firstname": "婴", "lastname": "青凤", "force": "FORCE_YOUMINGGONG", "title": "幽冥宫玄狐使",
     "dongjing": 32, "gangrou": -42, "zhipu": 9, "yinyang": -40,
     "neigong": 29, "boji": 33, "jianfa": 36, "daofa": 32, "changbing": 31, "anqi": 64, "qimen": 82,
     "superskills": [{"id": "SUPERSKILL_JIANGHUXINFA", "learn": [0, 1, 2]},
                     {"id": "SUPERSKILL_YINGXIONGXINFA", "learn": [0, 1, 2]},
                     {"id": "SUPERSKILL_LIHUNSHU", "learn": [0, 1, 2, 3]},
                     {"id": "SUPERSKILL_TIANLEIDIHUOYIN", "learn": "All"}],
     "running": {"id": "SUPERSKILL_LIHUNSHU"},
     "skill_counter": {"id": "SKILL_TIANLEIDIHUOYIN_1"},
     "equipment": [{"id": "ITEM_FENGSHOU", "position": "MainHand"},
                   {"id": "ITEM_YANWEIBIAO", "position": "ViceHand"}],
     "items": [],
     "criticaltxt": "淮南皓月冷千山，冥冥归去无人管！"}
