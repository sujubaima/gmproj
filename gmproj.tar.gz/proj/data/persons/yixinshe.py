# -- coding: utf-8 --

# 兰紫薇
PERSON_LAN_ZIWEI = \
    {"firstname": "兰", "lastname": "紫薇", "title": "兰台紫薇",
     "dongjing": 9, "gangrou": -18, "zhipu": 21,
     "neigong": 57, "boji": 30, "jianfa": 62, "daofa": 18, "changbing": 19, "anqi": 37, "qimen": 50, "yinyang": -7,
     "superskills": [{"id": "SUPERSKILL_JIANGHUXINFA", "learn": [0, 1, 2]},
                     {"id": "SUPERSKILL_JINGUANYUSUOJUE", "learn": "All"},
                     {"id": "SUPERSKILL_LONGHUAJIANSHU", "learn": [0, 1, 2]},
                     {"id": "SUPERSKILL_TONGGUIJIANFA", "learn": [0]}],
     "skill_counter": {"id": "SKILL_LONGHUAJIANSHU_1"},
     "equipment": [{"id": "ITEM_HEBI", "position": "MainHand"}],
     "items": [],
     "running": {"id": "SUPERSKILL_JINGUANYUSUOJUE"},
     "criticaltxt": "针砭之道，若风之吹云，明乎见天。"}