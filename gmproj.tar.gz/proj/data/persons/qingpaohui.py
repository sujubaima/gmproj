# -- coding: utf-8 -- 
 
# 钟不俗     
PERSON_ZHONG_BUSU = \
    {"firstname": "钟", "lastname": "不俗", "title": "青袍会杀手",
     "dongjing": 19, "gangrou": 11, "zhipu": 4, "yinyang": -10,
     "neigong": 40, "boji": 14, "jianfa": 18, "daofa": 57, "changbing": 4, "anqi": 44, "qimen": 47, 
     "superskills": [{"id": "SUPERSKILL_JIANGHUXINFA", "learn": "All"},
                     {"id": "SUPERSKILL_TIANYANGONG", "learn": "All"},
                     {"id": "SUPERSKILL_HEIFENGDAO", "learn": "All"}],
     "running": {"id": "SUPERSKILL_TIANYANGONG"},
     "equipment": [{"id": "ITEM_PODAO", "position": "MainHand"}],
     "items": [],
     "criticaltxt": "死人才不会走漏风声。",
     "conversation": "SCRIPT_ZHONGBUSU_1"}
     

# 李万     
PERSON_LI_WAN = \
    {"firstname": "李", "lastname": "万", "title": "青袍会杀手",
     "dongjing": 8, "gangrou": 20, "zhipu": -6, "yinyang": 0,
     "neigong": 27, "boji": 25, "jianfa": 3, "daofa": 49, "changbing": 10, "anqi": 37, "qimen": 30,
     "superskills": [{"id": "SUPERSKILL_JIANGHUXINFA", "learn": "All"},
                     {"id": "SUPERSKILL_FENJINXIGUDAO", "learn": "All"}],
     "equipment": [{"id": "ITEM_PODAO", "position": "MainHand"}],
     "items": [],
     "criticaltxt": "没有什么事情是一刀下去不能解决的，如果不行，就再来一刀。",
     "conversation": "SCRIPT_ZHONGBUSU_1"}
