# -- coding: utf-8 --

# 班觉嘉措
PERSON_SUONAN_RAODAN = \
    {"firstname": "班觉", "lastname": "嘉措", "title": "密教护法", "sex": 0,
     "dongjing": 10, "gangrou": 20, "zhipu": 8,
     "neigong": 40, "boji": 42, "jianfa": 10, "daofa": 18, "changbing": 35, "anqi": 3, "qimen": 12, "yinyang": 18,
     "superskills": [{"id": "SUPERSKILL_JIANGHUXINFA", "learn": [0, 1, 2]},
                     {"id": "SUPERSKILL_YOUXIAXINFA", "learn": [0, 1, 2]}],
     "equipment": [],
     "items": []}
  
  
# 索南饶丹
PERSON_SUONAN_RAODAN = \
    {"firstname": "索南", "lastname": "饶丹", "title": "密教弟子", "sex": 0,
     "dongjing": 10, "gangrou": 20, "zhipu": 8,
     "neigong": 40, "boji": 42, "jianfa": 10, "daofa": 18, "changbing": 35, "anqi": 3, "qimen": 12, "yinyang": 18,
     "superskills": [{"id": "SUPERSKILL_JIANGHUXINFA", "learn": [0, 1, 2]},
                     {"id": "SUPERSKILL_YOUXIAXINFA", "learn": [0, 1, 2]}],
     "equipment": [],
     "items": []}