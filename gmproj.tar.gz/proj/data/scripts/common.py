# -- coding: utf-8 --

SCRIPT_DEFAULT_DIALOG = \
    [{"type": "Action.PersonSpeakAction",
      "content": "（该人物的对话暂未编写。）"}]
