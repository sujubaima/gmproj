from proj.data.scripts.common import *
from proj.data.scripts.suzhoucheng import *
from proj.data.scripts.qingpaohui import *
from proj.data.scripts.beichenpai import *
from proj.data.scripts.juquemen import *
from proj.data.scripts.shaolinsi import *
from proj.data.scripts.gaibang import *
from proj.data.scripts.tuition import *
