
ELEMENT_BUILDING = \
    {"name": "建筑", 
     "vision_half": {"character": "/", "thumbnail": "合", "effects": {}},
     "vision_full": {"character": "/", "thumbnail": "合", "effects": {}}}


ELEMENT_WALL = \
    {"name": "围墙", 
     "vision_half": {"character": "/", "effects": {}},
     "vision_full": {"character": "/", "effects": {}}}


ELEMENT_TOWER = \
    {"name": "高塔",
     "vision_half": {"character": "/", "thumbnail": "Д ", "effects": {}},
     "vision_full": {"character": "/", "thumbnail": "Д", "effects": {}}}


ELEMENT_ROCK = \
    {"name": "岩石",
     "vision_half": {"character": "/", "effects": {}},
     "vision_full": {"character": "/", "effects": {}}}

