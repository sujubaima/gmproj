from proj.data.superskills.neigong import *
from proj.data.superskills.boji import *
from proj.data.superskills.jianfa import *
from proj.data.superskills.daofa import *
from proj.data.superskills.changbing import *
from proj.data.superskills.qimen import *
from proj.data.superskills.anqi import *
from proj.data.superskills.special import *