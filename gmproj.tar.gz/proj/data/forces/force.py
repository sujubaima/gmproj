# -- coding: utf-8 --

# 幽冥宫 
FORCE_YOUMINGGONG = \
    {"name": "幽冥宫",
     "relationship": {"FORCE_SHAOLINSI": 50,
                      "FORCE_WUDANGPAI": 40,
                      "FORCE_YUQINGGONG": 50,
                      "FORCE_TIANTAIAN": 50,
                      "FORCE_GAIBANG": 40,
                      "FORCE_BEICHENPAI": 50,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 100}}


# 少林寺
FORCE_SHAOLINSI = \
    {"name": "少林寺",
     "relationship": {"FORCE_SHAOLINSI": 100,
                      "FORCE_WUDANGPAI": 75,
                      "FORCE_YUQINGGONG": 70,
                      "FORCE_TIANTAIAN": 75,
                      "FORCE_GAIBANG": 75,
                      "FORCE_BEICHENPAI": 70,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 40}}


# 武当派
FORCE_WUDANGPAI = \
    {"name": "武当派",
     "relationship": {"FORCE_SHAOLINSI": 70,
                      "FORCE_WUDANGPAI": 100,
                      "FORCE_YUQINGGONG": 75,
                      "FORCE_TIANTAIAN": 70,
                      "FORCE_GAIBANG": 75,
                      "FORCE_BEICHENPAI": 70,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 25}}


# 玉清宫
FORCE_YUQINGGONG = \
    {"name": "玉清宫",
     "relationship": {"FORCE_SHAOLINSI": 70,
                      "FORCE_WUDANGPAI": 70,
                      "FORCE_YUQINGGONG": 100,
                      "FORCE_TIANTAIAN": 50,
                      "FORCE_GAIBANG": 65,
                      "FORCE_BEICHENPAI": 75,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 35}}


# 天台庵
FORCE_TIANTAIAN = \
    {"name": "天台庵",
     "relationship": {"FORCE_SHAOLINSI": 75,
                      "FORCE_WUDANGPAI": 65,
                      "FORCE_YUQINGGONG": 50,
                      "FORCE_TIANTAIAN": 100,
                      "FORCE_GAIBANG": 70,
                      "FORCE_BEICHENPAI": 70,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 30}}


# 丐帮
FORCE_GAIBANG = \
    {"name": "丐帮",
     "relationship": {"FORCE_SHAOLINSI": 70,
                      "FORCE_WUDANGPAI": 70,
                      "FORCE_YUQINGGONG": 70,
                      "FORCE_TIANTAIAN": 70,
                      "FORCE_GAIBANG": 100,
                      "FORCE_BEICHENPAI": 60,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 20}}


# 九溪派
FORCE_JIUXIPAI = \
    {"name": "九溪派",
     "relationship": {"FORCE_SHAOLINSI": 60,
                      "FORCE_WUDANGPAI": 60,
                      "FORCE_YUQINGGONG": 65,
                      "FORCE_TIANTAIAN": 65,
                      "FORCE_GAIBANG": 55,
                      "FORCE_BEICHENPAI": 40,
                      "FORCE_JIUXIPAI": 100,
                      "FORCE_YOUMINGGONG": 40}}

# 北辰派
FORCE_BEICHENPAI = \
    {"name": "北辰派",
     "relationship": {"FORCE_SHAOLINSI": 75,
                      "FORCE_WUDANGPAI": 75,
                      "FORCE_YUQINGGONG": 70,
                      "FORCE_TIANTAIAN": 70,
                      "FORCE_GAIBANG": 75,
                      "FORCE_BEICHENPAI": 100,
                      "FORCE_JIUXIPAI": 50,
                      "FORCE_YOUMINGGONG": 40}}
