# -- encoding: utf-8 --

MAP_WITHPERSON = \
{
    "width": 10,
    "height": 10,
    "name": "testperson",
    "terrans": [],
    "objects": [],
    "persons": [
        {
            "id": "PERSON_TIAN_WEI",
            "location": "(4, 4)"
        }
    ],
    "start_locations": []
}

