from proj.data.maps.baibingtang import *
from proj.data.maps.youminggong import *
from proj.data.maps.world import *

from proj.data.maps.suzhoucheng import *

from proj.data.maps.testwithperson import *


from proj.data.maps.hangzhoucheng import *

from proj.data.maps.tuition import *

from proj.data.maps.world import *

from proj.data.maps.shaolinsi import *

from proj.data.maps.testmap import *
