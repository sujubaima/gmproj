# -- encoding: utf-8 --

MAP_TEST_ASTAR = \
{
    "width": 7,
    "height": 5,
    "name": "\u6d4b\u8bd5A\u661f",
    "terrans": [
        {
            "style": "TERRAN_WATER",
            "points": [
                "(1, 1)",
                "(1, 3)",
                "(2, 1)",
                "(2, 3)",
                "(3, 1)",
                "(3, 3)",
                "(4, 1)",
                "(4, 3)",
                "(5, 2)"
            ]
        }
    ],
    "objects": [],
    "persons": [],
    "start_locations": [],
    "transport_locations": {}
}

