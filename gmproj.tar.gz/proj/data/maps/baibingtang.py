# -- coding: utf-8 --

MAP_BTL_BAIBINGTANGZONGDUO = \
    {"name": "百兵堂：总舵", "width": 7, "height": 7,
     "objects": [{"name": "大锻炉", "style": "ELEMENT_BUILDING", 
                  "points": ["(1, 2)", "(3, 2)", "(5, 2)", "(1, 4)", "(3, 4)", "(5, 4)"]}],
     "start_locations": [["(0, 3)", "(1, 3)", "(2, 2)", "(2, 4)", "(2, 3)"],
                         ["(6, 3)", "(5, 3)", "(4, 3)", "(6, 2)", "(6, 1)", "(6, 4)", "(6, 5)"]]}
