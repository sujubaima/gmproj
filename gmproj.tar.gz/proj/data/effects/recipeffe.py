# -- coding: utf-8 --
EFFECT_ITEM_MAKE = {"style": 1, "module": "proj.entity.effect", "class": "ItemMakeEffect"}

EFFECT_QINGZHENGLUYU_RECIPE = \
    {"style": 1, "module": "proj.entity.effect", "class": "ItemMakeEffect",
     "item": "ITEM_QINGZHENGLUYU", "rate": 0.1}
