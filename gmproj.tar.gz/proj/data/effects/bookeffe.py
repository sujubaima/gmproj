# -- coding: utf-8 --

EFFECT_SUPERSKILL_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect"}
    

EFFECT_LANYANGJIANFA_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_LANYANGJIANFA"}
     
     
EFFECT_HUANGLUKUZHUJIAN_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_HUANGLUKUZHUJIAN"}
     
     
EFFECT_BOYUNJIANRIDAO_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_BOYUNJIANRIDAO"}
     
     
EFFECT_QIXINGNIMAI_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_QIXINGNIMAI"}
     
     
EFFECT_TIANLEIDIHUOYIN_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_TIANLEIDIHUOYIN"}


EFFECT_POFENGBADAO_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_POFENGBADAO"}
     

EFFECT_ZIXIASHENGONG_STUDY = \
    {"style": 1, "module": "proj.entity.effect", "class": "SkillStudyEffect",
     "superskill": "SUPERSKILL_ZIXIASHENGONG"}