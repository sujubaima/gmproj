HP = "气血"
MP = "内力"
INJURY = "外伤"
WOUND = "内伤"
POISON_HP = "风毒"
POISON_MP = "瘀毒"

NEIGONG = "内功"
BOJI = "搏击"
JIANFA = "剑法"
DAOFA = "刀法"
CHANGBING = "长兵"
QIMEN = "奇门"
ANQI = "暗器"

LINGDONG = "灵动"
CHENJING = "沉静"
GANGMENG = "刚猛"
ROUYI = "柔易"
YINGWU = "颖悟"
PUZHUO = "朴拙"


