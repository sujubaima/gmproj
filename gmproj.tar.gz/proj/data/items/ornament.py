# -- coding: utf-8 --

ITEM_MONIZHU = \
    {"name": "摩尼珠", "rank": 3, "tags": "Equip,Ornament", "shape": "Around,0,0,0",
     "weight": 0.2, "volume": 0.1,
     "effects": [{"id": "EXERT.LAMBDA.EFFECT_CHANGJIAN_ATTR"}],
     "description": "即俗称的如意珠，传说为生于龙脑，又说为舍利所化。佩戴它可使诸法皆通，百毒不害。"}


ITEM_LANHUALVRONG = \
    {"name": "蓝花绿绒", "rank": 4, "tags": "Equip,Ornament", "shape": "Around,0,0,0",
     "weight": 0.1, "volume": 0.6, 
     "effects": [{"id": "EXERT.STATUS_XUNFENG"}],
     "description": "生于高寒之处的香草，一般只生红花，生蓝花者为稀世珍品。"}
