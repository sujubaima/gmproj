# -- coding: utf-8 --

ITEM_JINCHUANGYAO = \
    {"name": "金疮药", "rank": 0, "tags": "Medicine", "shape": "Point,1,0", "targets": "Friends",
     "weight": 0.2, "volume": 0.2, "money": 100,
     "effects": [{"id": "EFFECT_HUICHUN"}]}

ITEM_FENGDU = \
    {"name": "蜂毒", "rank": 1, "tags": "Poison", "shape": "Point,1,0",
     "weight": 0.2, "volume": 0.2,
     "effects": [{"id": "EFFECT_HUICHUN"}]}
