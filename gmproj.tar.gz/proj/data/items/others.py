# -- coding: utf-8 --

ITEM_MONEY = \
    {"name": "金钱", "rank": 4, "weight": 0, "volume": 0,
     "description": "多多益善之物"}


ITEM_BITCOIN = \
    {"name": "比特币", "rank": 4, "weight": 0, "volume": 0,
     "description": "在这个世界一点用都没有"}


ITEM_TANGSHIPINHUI = \
    {"name": "《唐诗品汇》", "rank": 1, 
     "weight": 1.0, "volume": 0.5,
     "description": "明代高棅编撰的唐诗选集，里面似乎既没有武学可练，也没有什么技艺可学"}   