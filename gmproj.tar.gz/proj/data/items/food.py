# -- coding: utf-8 --

ITEM_HUADIAO = \
    {"name": "花雕", "rank": 1, "tags": "Material,Wine",
     "weight": 1, "volume": 0.5,
     "description": "浙江一带产出的黄酒，又名女儿红"}

ITEM_FENGGANGJIU = \
    {"name": "封缸酒", "rank": 1, "tags": "Material,Wine",
     "weight": 1, "volume": 0.5,
     "description": "江苏、江西一带产出的黄酒"}

ITEM_QINGZHENGLUYU = \
    {"name": "清蒸鲈鱼", "rank": 1, "tags": "Food"}
