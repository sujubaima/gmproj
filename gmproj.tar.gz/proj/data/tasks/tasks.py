# -- coding: utf-8 --

TASK_HUIGUIXIANSHI = "回归现实"

TASK_HUIGUIXIANSHI_1 = "你在吴中客栈遇到同事万鹏飞，他告诉你现在所处的世界是一个虚幻的武侠世界。想要回到现实就必须找到传说中的出口。"

TASK_SHENGCUNZHIDAO = "生存之道"

TASK_SHENGCUNZHIDAO_1 = "在苏州城里四处逛逛，了解一下如何在江湖里生存。"

TASK_LUBANZAISHI = "鲁班再世"

TASK_LUBANZAISHI_1 = "苏州城的工匠叶忠一心想要提高自己的营造水平，你可以试着帮帮他。"

TASK_BEICHENDIZI = "北辰弟子"

TASK_BEICHENDIZI_1 = "你在苏州城遇到北辰派弟子唐兴，他似乎正因为每天都要读四书五经而烦躁。"

TASK_BEICHENDIZI_2 = "唐兴偷学了一招大师兄的裴将军剑，但不敢在门派中练习，希望你能与他切磋过招，帮助他早日精熟。"

TASK_SUZHOUJIDAO = "苏州缉盗"

TASK_SUZHOUJIDAO_1 = "苏州城外近日出现了以薛四彭为首的盗贼，县令耿朱桥正在招募勇士用于剿匪。"

TASK_YOUMINGLU = "幽冥路"

TASK_YOUMINGLU_1 = "你放了强盗头子薛四彭一条生路，他表示后续见面一定会有报答。"

TASK_LUOHUAYOUYI = "落花有意"

TASK_LUOHUAYOUYI_1 = "北辰派的二弟子骆逸近日不知所踪，他的师兄陈挺之希望你能帮忙打听一下他的下落。"

TASK_SHUIMOXINQIANG = "水磨新腔"

TASK_SHUIMOXINQIANG_1 = "苏州名士冯梦龙近日正在推广一种新的声腔，需要有好的戏本来进行打谱。你可以在全国各地留意一下。"

TASK_CAOYAOBUZU = "草药不足"

TASK_CAOYAOBUZU_1 = "苏州铁匠铺的铁矿不足了，如果你能提供10份铁矿，铁匠一定会有酬谢。"

TASK_XIONGDIHUI = "兄弟会"

TASK_XIONGDIHUI_1 = "苏州吴山客栈里有几个鬼鬼祟祟的家伙，似乎在打知府耿朱桥的主意，或许应该提前通知耿先生。"

TASK_XIONGDIHUI_2 = "他们其中一人似乎提到一个叫做青袍会的组织，如果你认识熟悉江湖掌故的人，可以向他打听一下它的情况。"

TASK_XIONGDIHUI_3 = "你向耿朱桥汇报了吴山客栈的见闻，耿朱桥表现得相当镇静。既然耿先生都不在意，你也暂且放心好了。"

TASK_XIONGDIHUI_4 = "苏州游侠黄金颊听见青袍会这个名字，反应十分奇怪。可以顺着这条线继续追查。"

TASK_YANZHAOXING = "燕赵行"

TASK_YANZHAOXING_1 = "耿朱桥让石敬岩替自己去燕赵镖局探望总镖头刘德长，如果感兴趣的话，你也可以顺路去看看。"

TASK_YINJIANTIEDI = "银剑铁笛"

TASK_YINJIANTIEDI_1 = "传说中苏州知府耿朱桥武艺高强，但是却少有人知道他的师承，有空的话可以打听一下。"