from proj.data.skills.neigong import *
from proj.data.skills.boji import *
from proj.data.skills.jianfa import *
from proj.data.skills.daofa import *
from proj.data.skills.changbing import *
from proj.data.skills.anqi import *
from proj.data.skills.qimen import *
from proj.data.skills.special import *
