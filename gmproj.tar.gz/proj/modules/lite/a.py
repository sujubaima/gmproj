a = 888

 dir(a)
