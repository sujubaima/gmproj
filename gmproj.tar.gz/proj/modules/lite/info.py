# -- coding: utf-8 --
MOD_SHOW_NAME = "系统简化版"
MOD_VERSION = "0.1.0"
