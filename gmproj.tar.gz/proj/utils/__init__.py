from proj.utils.ratio import if_rate
from proj.utils.ratio import random_gap
from proj.utils.ratio import Exponential
