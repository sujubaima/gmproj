from proj.console.handlers.system import *
#from proj.console.handlers.battle import *
#from proj.console.handlers.world import *
#from proj.console.handlers.person import *
#from proj.console.handlers.team import *
#from proj.console.handlers.special import *

from proj.console.handlers.common import *
from proj.console.handlers.trade import *
from proj.console.handlers.skill import *
from proj.console.handlers.equip import *
from proj.console.handlers.scene import *
from proj.console.handlers.battle import *
from proj.console.handlers.team import *
from proj.console.handlers.special import *
from proj.console.handlers.acmsg import *
