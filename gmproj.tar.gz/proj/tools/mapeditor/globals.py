# -- coding: utf-8 --

MAP = None
MAP_MODULE = None