#!/bin/sh

python $(dirname $0)/../proj/test/test_battle.py
