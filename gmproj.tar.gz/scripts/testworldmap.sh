#!/bin/sh

python $(dirname $0)/../proj/test/test_worldmap.py
