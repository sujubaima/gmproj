python $(dirname $0)/../proj/main.py
